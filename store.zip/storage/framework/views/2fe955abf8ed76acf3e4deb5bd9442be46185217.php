<?php $__env->startSection('title', 'Оформить заказ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="registration-container mt-4">
        <h4 class="fw-700 text-center mb-4 d-block align-items-center">Подтвердите заказ</h4>
        <p class="text-center">Общая стоимость: <b><?php echo e($order->calculateFullSum()); ?> ₽</b></p>

        <form action="<?php echo e(route('basket-confirm')); ?>" method="POST">
            <div class="mb-3">
                <label for="name" class="control-label">Имя: </label>
                <input type="text" name="name" id="name" value="" class="form-control">
            </div>
            <div class="mb-3">
                <label for="phone" class="control-label">Номер телефона: </label>
                <input type="text" name="phone" id="phone" value="" class="form-control">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if(auth()->guard()->guest()): ?>
            <div class="mb-3">
                <label for="email" class="control-label">Email: </label>
                <input type="text" name="email" id="email" value="" class="form-control">
            </div>
            <?php endif; ?>

            <div class="mb-3">
                <label for="name" class="control-label">Способ получения: </label>
                <select id="recieve_method" name="recieve_method" class="form-select" aria-label="Default select example">
                    <option value="самовывоз" selected>Самовывоз</option>
                    <option value="доставка">Доставка</option>
                </select>
            </div>
            <div class="mb-3" id="address">
                <label for="address" class="control-label">Адрес: </label>
                <input type="text" name="address" id="" value="" class="form-control">
                <div class="form-text">Введите адрес: улица, дом, номер квартиры (ул. Парковая, 8, кв. 43)</div>
            </div>
            
            <div class="row mb-3 mt-4">
            <div class="col-2 position-relative">
                <img class="info d-block m-auto" src="<?php echo e(asset('img/point.svg')); ?>" alt="point">
            </div>
            <div class="col-10">
                <p class="m-0 ">
                    Мы подготовим для Вас товар, и Вы сможете забрать его в магазине
                </p>
            </div>
        </div>
        <div class="row mb-4">
            <div class="col-2 position-relative">
                <img class="info d-block m-auto" src="<?php echo e(asset('img/box.svg')); ?>" alt="point">
            </div>
            <div class="col-10">
                <p class="m-0">
                    Курьер доставит товар до нужного места, после подтверждения заказа
                </p>
            </div>
        </div>
            <?php echo csrf_field(); ?>
            <input type="submit" class="order-btn mt-4" value="Заказать">
        </form>
    </div>
    <script>
        $(function()
        {
            $('#address').hide();
            $('#recieve_method').change(function()
            {
                if($('#recieve_method').val() == 'доставка'){
                    $('#address').show();
                }
                if($('#recieve_method').val() == 'самовывоз'){
                    $('#address').hide();
                }
            });
        }
        )
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\mh\resources\views/order.blade.php ENDPATH**/ ?>
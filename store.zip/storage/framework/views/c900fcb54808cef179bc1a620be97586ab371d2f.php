Уважаемый клиент, товар <?php echo e($product->name); ?> появился в наличии.

<a href="<?php echo e(route('product', [$product->category->code, $product->code])); ?>">Узнать подробности</a>
<?php /**PATH C:\OSPanel\domains\mh\resources\views/mail/subscription.blade.php ENDPATH**/ ?>
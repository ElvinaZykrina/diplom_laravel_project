<p>Уважаемый(ая) <?php echo e($name); ?></p>

<p>Ваш заказ на сумму <?php echo e($fullSum); ?> создан</p>

<table>
    <tbody>
    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="<?php echo e(route('product', [$product->category->code, $product->code])); ?>">
                    <img height="56px" src="<?php echo e(Storage::url($product->image)); ?>">
                    <?php echo e($product->name); ?>

                </a>
            </td>
            <td><span class="badge"><?php echo e($product->pivot->count); ?></span>
                <div class="btn-group form-inline">
                    <?php echo $product->description; ?>

                </div>
            </td>
            <td><?php echo e($product->price); ?> руб.</td>
            <td><?php echo e($product->getPriceForCount()); ?> руб.</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\OSPanel\domains\mh\resources\views/mail/order_created.blade.php ENDPATH**/ ?>
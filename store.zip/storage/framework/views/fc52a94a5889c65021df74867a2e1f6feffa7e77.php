<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('img/Group 207.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/starter-template.css')); ?>"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/adaptation.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Интернет Магазин: <?php echo $__env->yieldContent('title'); ?></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

</head>
<body>
    <header class="header">
        <div class="header__container">
            <div class="logo">
                <a href="" id="header-logo"><img src="<?php echo e(asset('img/logo.svg')); ?>"
                        alt="drive"></a>
            </div>
            <nav class="header__nav">
                <ul class="menu header__menu mb-0">
                    <li <?php echo Route::currentRouteNamed('main') ? 'class="menu_active"' : '' ?>>
                        <a href="<?php echo e(route('main')); ?>" class="menu__item">Главная</a>
                    </li>
                    <div class="line_hidden"></div>
                    <li <?php echo Route::currentRouteNamed('index') ? 'class="menu_active"' : '' ?> || <?php echo Route::currentRouteNamed('categor*') ? 'class="menu_active"' : '' ?> || <?php echo Route::currentRouteNamed('search') ? 'class="menu_active"' : '' ?> || <?php echo Route::currentRouteNamed('product') ? 'class="menu_active"' : '' ?>>
                        <a href="<?php echo e(route('index')); ?>" class="menu__item">Каталог</a>
                    </li>
                    <div class="line_hidden"></div>
                    <li <?php echo Route::currentRouteNamed('service') ? 'class="menu_active"' : '' ?>>
                        <a href="<?php echo e(route('service')); ?>" class="menu__item">Сервис и поддержка</a>
                    </li>
                    <div class="line_hidden"></div>
                    <li <?php echo Route::currentRouteNamed('basket*') ? 'class="menu_active"' : '' ?> >
                        <a href="<?php echo e(route('basket')); ?>" class="menu__item">Корзина</a>
                    </li>
                    <?php if(auth()->guard()->guest()): ?>
                        <div class="line_hidden"></div>
                        <li <?php echo Route::currentRouteNamed('login') ? 'class="menu_active"' : '' ?>>
                            <a href="<?php echo e(route('login')); ?>" class="menu__item">Войти</a>
                        </li>
                        <div class="line_hidden"></div>
                        <li <?php echo Route::currentRouteNamed('register') ? 'class="menu_active"' : '' ?>>
                            <a href="<?php echo e(route('register')); ?>" class="menu__item">Зарегистрироваться</a>
                        </li>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                            <div class="line_hidden"></div>
                            <li <?php echo Route::currentRouteNamed('home') ? 'class="menu_active"' : '' ?>>
                                <a href="<?php echo e(route('home')); ?>" class="menu__item">Панель администратора</a>
                            </li>
                            <?php else: ?>
                            <div class="line_hidden"></div>
                            <li <?php echo Route::currentRouteNamed('person.orders.index') ? 'class="menu_active"' : '' ?>>
                                <a href="<?php echo e(route('person.orders.index')); ?>" class="menu__item">Мои заказы</a>
                            </li>
                        <?php endif; ?>
                    <div class="line_hidden"></div>
                    <li <?php echo Route::currentRouteNamed('get-logout') ? 'class="menu_active"' : '' ?>>
                        <a href="<?php echo e(route('get-logout')); ?>" class="menu__item">Выйти</a>
                    </li>
                    <?php endif; ?>


                </ul>
            </nav>
            <div class="menu-burger__header">
                <span></span>
            </div>
        </div>
    </header>

    <div class="my-container search_dropdown">
        <div class="dropdown">
            <button onclick="myFunction()" class="dropbtn">Каталог</button>
            <div id="myDropdown" class="dropdown-content">
                    <a href="<?php echo e(route('index')); ?>">Все товары</a>
                    <div class="line_hidden"></div>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('category', $category->code)); ?>"><?php echo e($category->name); ?></a>
                    <div class="line_hidden"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <a href="#">Бытовая химия</a>
                <div class="line_hidden"></div>
                <a href="#">Товары для дома</a>
                <div class="line_hidden"></div>
                <a href="#">Дача и сад</a>
                <div class="line_hidden"></div>
                <a href="#">Хозтовары</a>
                <div class="line_hidden"></div>
                <a href="#">Товары для отдыха</a>
                <div class="line_hidden"></div> -->
            </div>
        </div>
        <div class="search-container">
            <form action="<?php echo e(route('search', $category)); ?>" method="get">
                <div class="d-flex justify-content-center search-input-container">
                    <input type="text" name="s" id="s" class="search-input" value="<?php echo e(request()->s); ?>" placeholder="Введите название товара">
                    <button class="btn-search" type="submit">Найти</button>
                </div>
            </form>
        </div>
        <!-- <div class="search">
        </div> -->
    </div>

    <div class="my-container">
        <?php if(session()->has('success')): ?>
            <p class="alert my-alert-success"><?php echo e(session()->get('success')); ?></p>
        <?php endif; ?>
        <?php if(session()->has('warning')): ?>
            <p class="alert my-alert-warning"><?php echo e(session()->get('warning')); ?></p>
        <?php endif; ?>
    </div>

    <?php echo $__env->yieldContent('content'); ?>


    <div class="footer mt-5">
        <div class="pt-5">
            <div class="my-container me-auto ms-auto">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <h5 class="mb-3">Магазин хозяйственных товаров 1000 мелочей</h5>
                        <p>В нашем каталоге: хозяйственные товары, посуда, бытовая химия; бытовая техника; косметика,
                            средства по уходу и гигиене; товары для интерьера, хранения, уборки; инструменты, садовые
                            принадлежности, средства ухода за растениями, удобрения, репелленты; аксессуары для ванной
                            комнаты, электротовары и многое другое.
                        </p>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <h5 class="mb-3">Контакты</h5>
                        <ul class="contact-list">
                            <li><a href="tel:">+7(999)-999-99-99</a></li>
                            <li><a href="tel:">8 (800) 888-00-88</a></li>
                            <li><a href="mail:">1000melochey@mail.ru</a></li>
                        </ul>
                    </div>
                </div>
                <div class="footer-underline"></div>
                <div class="d-flex justify-content-between">
                    <div class="d-flex flex-wrap me-4 footer-nav tiny-font">
                        <a href="#">Главная</a>
                        <a href="#">Сервис и поддержка</a>
                        <a href="#">Каталог товаров</a>
                    </div>
                    <div class="d-flex flex-wrap tiny-font">
                        <p class="fw-700">1000 мелочей </p>
                        <p>| ИП Контиевская. ©2022 все права защищены</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script defer src="<?php echo e(asset('js/form.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/menu.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/catalog_dropdown.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\mh\resources\views/layouts/master.blade.php ENDPATH**/ ?>
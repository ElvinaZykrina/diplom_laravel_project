<?php if(isset($category)): ?>
        <?php $__env->startSection('title', 'Редактировать Категорию ' . $category->name); ?>
    <?php else: ?>
        <?php $__env->startSection('title', 'Создать Категорию'); ?>
<?php endif; ?>


<?php $__env->startSection('title', 'Добавление категории'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="mb-5">
        <?php if(isset($category)): ?>
            <h1>Редактировать Категорию <b><?php echo e($category->name); ?></b></h1>
        <?php else: ?>
            <h1>Добавить Категорию</h1>
        <?php endif; ?>
    </div>

    <form method="POST" enctype="multipart/form-data"
        <?php if(isset($category)): ?>
                action="<?php echo e(route('categories.update', $category)); ?>"
            <?php else: ?>
                action="<?php echo e(route('categories.store')); ?>"
        <?php endif; ?>
        >
        <?php if(isset($category)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div>

            <div class="input-group row">
                <label for="code" class="col-sm-2 col-form-label fw-bold">Код: </label>
                <div class="col-sm-6">
                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" class="form-control" name="code" id="code"
                    value="<?php echo e(old('code', isset($category) ? $category->code : null)); ?>">
                </div>
            </div>
            <br>
            <div class="input-group row">
                <label for="name" class="col-sm-2 col-form-label fw-bold">Название: </label>
                <div class="col-sm-6">
                       <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" class="form-control" name="name" id="name"
                    value="<?php if(isset($category)): ?><?php echo e($category->name); ?><?php endif; ?>">
                </div>
            </div>
            <br>
            <div class="input-group row">
                <label for="description" class="col-sm-2 col-form-label fw-bold">Описание: </label>
                <div class="col-sm-6">
                       <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <textarea name="description" id="description" class="form-control" id="floatingTextarea2" style="height: 100px">
                        <?php if(isset($category)): ?><?php echo e($category->description); ?><?php endif; ?>
                    </textarea>
                </div>
            </div>
            <br>
            <div class="input-group row">
                <label for="image" class="col-sm-2 col-form-label fw-bold">Картинка: </label>
                <div class="col-sm-10">
                    <label class="btn btn-default btn-file">
                        Загрузить
                        <input type="file" style="display: none;" name="image" id="image">
                    </label>
                </div>
            </div>
            <button class="btn btn-success">Сохранить</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\mh\resources\views/auth/categories/form.blade.php ENDPATH**/ ?>
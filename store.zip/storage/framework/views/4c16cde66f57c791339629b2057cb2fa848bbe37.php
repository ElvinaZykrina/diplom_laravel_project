<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Админка: <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    


    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- <link href="http://internet-shop.tmweb.ru/css/bootstrap.min.css" rel="stylesheet"> -->
    <link href="/css/admin.css" rel="stylesheet">
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-expand-md navbar-light navbar-laravel">
            <div class="container">


                    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                    <a class="navbar-brand" href="<?php echo e(route('index')); ?>">Вернуться на сайт</a>
                    <a class="navbar-brand" href="<?php echo e(route('categories.index')); ?>">Категории</a>
                    <a class="navbar-brand" href="<?php echo e(route('products.index')); ?>">Товары</a>
                    <a class="navbar-brand" href="<?php echo e(route('login')); ?>">Заказы</a>
                    <?php endif; ?>

                    <div id="navbar" class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                    </ul>

                    <?php if(auth()->guard()->guest()): ?>
                        <ul class="nav navbar-nav navbar-right">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>">Войти</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>">Зарегистрироваться</a>
                            </li>
                        </ul>
                    <?php endif; ?>

                    <?php if(auth()->guard()->check()): ?>
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li>
                                <a class="navbar-brand" href="<?php echo e(route('logout')); ?>">Выйти</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    <?php endif; ?>

                </div>
            </div>
        </nav>

        <div class="py-4">
            <div class="container">
                <div class="row justify-content-center">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\mh\resources\views/auth/layouts/master.blade.php ENDPATH**/ ?>
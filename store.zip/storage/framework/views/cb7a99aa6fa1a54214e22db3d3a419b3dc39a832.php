<?php $__env->startSection('title', 'Все товары'); ?>

<?php $__env->startSection('content'); ?>
    <div class="my-container">
        <div class="breadcrumps d-flex mb-3">
            <a class="breadcrumps-link success_link" href="<?php echo e(route('main')); ?>">Главная</a>
            <a class="success_link" href="<?php echo e(route('index')); ?>">Каталог товаров</a>
        </div>
        <div class="row">
            <!-- фильтр -->
            <div class="filters-container col-md-3 col-sm-12 m-0 mb-4">
                <form action="<?php echo e(route('index')); ?>" method="GET">
                <div class="filters p-3">
                    <div class="row mb-2">
                        <div class="col-md-12 col-sm-6">
                            <label class="fs-7" for="new">
                                <input class="me-2" type="checkbox" name="new" id="new" <?php if(request()->has('new')): ?> checked <?php endif; ?> >Новинка
                            </label>
                        </div>
                        <div class="col-md-12 col-sm-6">
                            <label class="fs-7" for="recommend">
                                <input class="me-2" type="checkbox" name="recommend" id="recommend" <?php if(request()->has('recommend')): ?> checked <?php endif; ?>>Рекомендуем
                            </label>
                        </div>
                        <div class="col-md-12 col-sm-6">
                            <label class="fs-7" for="hit">
                                <input class="me-2" type="checkbox" name="hit" id="hit" <?php if(request()->has('hit')): ?> checked <?php endif; ?>>Хит продаж
                            </label>
                        </div>
                    </div>
                    <p class="fw-700 fs-7 mb-1">Цена</p>
                    <div class="d-flex flex-wrap fs-7 mb-3">
                        <div class="col-md-12 col-sm-3 me-2">
                            <label class="filter-label mb-1" for="price_from">от
                                <input class="filter-input w-100" type="text" name="price_from" id="price_from"
                                    size="6" value="<?php echo e(request()->price_from); ?>">
                            </label>
                        </div>
                        <div class="col-md-12 col-sm-3">
                            <label class="filter-label" for="price_to">до
                                <input class="filter-input w-100" type="text" name="price_to" id="price_to"
                                    size="6" value="<?php echo e(request()->price_to); ?>">
                            </label>
                        </div>
                    </div>
                    <p class="fw-700 fs-7 mb-1">Сортировать по</p>
                    <div class="row mb-4">
                        <div class="col-12">
                        <select class="form-select"  id="inputGroupSelect01" name="sort">
                            <option value="created_at_new" <?php echo e(request()->input('sort') == 'created_at_new' ? 'selected' : ''); ?>>Сначала новые</option>
                            <option <?php echo e(request()->input('sort') == 'created_at_old' ? 'selected' : ''); ?> value="created_at_old">Сначала старые</option>
                            <option <?php echo e(request()->input('sort') == 'price_low' ? 'selected' : ''); ?> value="price_low">Сначала дешевые</option>
                            <option <?php echo e(request()->input('sort') == 'price_high' ? 'selected' : ''); ?> value="price_high">Сначала дорогие</option>
                        </select>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap">
                        <button type="submit" class="btn-filter me-2 mb-2">Фильтр</button>
                        <a href="<?php echo e(route('index')); ?>" class="btn-cancel mb-2">Стереть</a>
                    </div>
                </div>
                </form>
            </div>
            <!-- товары -->

            <div class="col-md-9 col-sm-12 products-container ">
                    
                    <?php if(count($products)): ?>
                        <ul class="products clearfix">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('layouts.card', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    <?php else: ?>
                        <div class="d-block text-center">
                            <h1>Ничего не нашлось по запросу «<?php echo e(request()->s); ?>»</h1>
                            <p>Попробуйте изменить или сократить запрос</p>
                            <img src="<?php echo e(asset('img/sadlupa.svg')); ?>" alt="norequest" style="width: 100px;">
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-center my-4">
                        <?php echo e($products->appends(['s'=>request()->s])->links()); ?>

                    </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\mh\resources\views/index.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('img/Group 207.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/starter-template.css')); ?>"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/adaptation.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Интернет Магазин: <?php echo $__env->yieldContent('title'); ?></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

</head>

<body>

            <div id="app">
                <nav class="navbar navbar-default navbar-expand-md navbar-light navbar-laravel">
                    <div class="container">
                            <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                                <a class="navbar-brand" href="<?php echo e(route('index')); ?>">Вернуться на сайт</a>
                                <a class="navbar-brand" href="<?php echo e(route('categories.index')); ?>">Категории</a>
                                <a class="navbar-brand" href="<?php echo e(route('products.index')); ?>">Товары</a>
                                <a class="navbar-brand" href="<?php echo e(route('login')); ?>">Заказы</a>
                            <?php endif; ?>
                            <div id="navbar" class="collapse navbar-collapse">
                        </div>
                    </div>
                </nav>
                <div class="py-4">
                    <div class="container">
                        <div class="row justify-content-center">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>
            </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script defer src="<?php echo e(asset('js/form.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/menu.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/catalog_dropdown.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\mh\resources\views/auth/layouts/masterAdmin.blade.php ENDPATH**/ ?>
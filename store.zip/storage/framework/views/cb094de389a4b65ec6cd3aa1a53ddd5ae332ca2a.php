<?php $__env->startSection('title', 'Категория ' . $category->name); ?>

<?php $__env->startSection('content'); ?>

    <div class="my-container">
        <h1><?php echo e($category->name); ?></h1>
        <!-- <?php echo e($category->products->count()); ?>

        <p><?php echo e($category->description); ?></p> -->
        <div class="breadcrumps d-flex mb-3">
            <a class="breadcrumps-link success_link" href="<?php echo e(route('main')); ?>">Главная</a>
            <a class="breadcrumps-link success_link" href="<?php echo e(route('index')); ?>">Каталог товаров</a>
            <a class="success_link" href="<?php echo e(route('category', $category->code)); ?>"><?php echo e($category->name); ?></a>
        </div>
        <div class="row">
            <div class="col-md-3 col-sm-12 m-0 mb-4">
                <div class="filters p-3">
                    <p class="fw-700 fs-7">Категория</p>
                    <div class="row mb-4">
                        <div class="col-md-12 col-sm-6">
                            <label class="fs-7" for="new">
                                <input class="me-2" type="checkbox" name="new" id="new">Новинка</label>
                        </div>
                        <div class="col-md-12 col-sm-6">
                            <label class="fs-7" for="recommend">
                                <input class="me-2" type="checkbox" name="recommend" id="recommend">Рекомендуем</label>
                        </div>
                        <div class="col-md-12 col-sm-6">
                            <label class="fs-7" for="wash">
                                <input class="me-2" type="checkbox" name="wash" id="wash">Моющие средства</label>
                        </div>
                        <div class="col-md-12 col-sm-6">
                            <label class="fs-7" for="dacha">
                                <input class="me-2" type="checkbox" name="dacha" id="dacha">Дача</label>
                        </div>
                    </div>
                    <p class="fw-700 fs-7 mb-1">Цена</p>
                    <div class="d-flex flex-wrap fs-7 mb-3">
                        <div class="col-md-12 col-sm-2 me-2">
                            <label class="filter-label mb-1" for="price_from">от
                                <input class="filter-input w-100" type="text" name="price_from" id="price_from"
                                    size="6" value="">
                            </label>
                        </div>
                        <div class="col-md-12 col-sm-2">
                            <label class="filter-label" for="price_to">до
                                <input class="filter-input w-100" type="text" name="price_to" id="price_to"
                                    size="6" value="">
                            </label>
                        </div>
                    </div>
                    <p class="fw-700 fs-7 mb-1">Сортировать по</p>
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="flexRadioDefault"
                                    id="flexRadioDefault1">
                                <label class="form-check-label" for="flexRadioDefault1">
                                    цена по возрастанию
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="flexRadioDefault"
                                    id="flexRadioDefault3">
                                <label class="form-check-label" for="flexRadioDefault3">
                                    цена по убыванию
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="flexRadioDefault"
                                    id="flexRadioDefault2" checked>
                                <label class="form-check-label" for="flexRadioDefault2">
                                    по популярности
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap">
                        <button class="btn-filter me-2 mb-2">Фильтр</button>
                        <button class="btn-cancel mb-2">Стереть</button>
                    </div>
                </div>
            </div>
            <div class="col-md-9 col-sm-12">
                <div class="d-flex flex-wrap justify-content-around">
                    <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('layouts.card', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex justify-content-center">
                    <nav aria-label="Page navigation example ">
                        <ul class="pagination">
                            <li class="page-item ">
                                <a class="page-link text-dark" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item "><a class="page-link text-dark" href="#">1</a></li>
                            <li class="page-item "><a class="page-link text-dark" href="#">2</a></li>
                            <li class="page-item "><a class="page-link text-dark" href="#">3</a></li>
                            <li class="page-item ">
                                <a class="page-link text-dark" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\mh\resources\views/category.blade.php ENDPATH**/ ?>
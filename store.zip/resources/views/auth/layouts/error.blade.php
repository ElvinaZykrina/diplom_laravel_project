@error($fieldName)
    <div class="alert alert-danger">
        {{$message}}
    </div>
@enderror

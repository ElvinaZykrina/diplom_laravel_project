@extends('layouts.master')

@section('title', 'Оформить заказ')

@section('content')
    <div class="registration-container mt-4">
        <h4 class="fw-700 text-center mb-4 d-block align-items-center">Подтвердите заказ</h4>
        <p>Общая стоимость: <b>{{ $order->calculateFullSum() }} ₽.</b></p>
        <form action="{{ route('basket-confirm') }}" method="POST">
            <div class="mb-3">
                <label for="name" class="control-label">Имя: </label>
                <input type="text" name="name" id="name" value="" class="form-control">
            </div>
            <div class="mb-3">
                <label for="phone" class="control-label">Номер телефона: </label>
                <input type="text" name="phone" id="phone" value="" class="form-control">
            </div>
            <div class="mb-3">
                <label for="name" class="control-label">Email: </label>
                <input type="text" name="email" id="email" value="" class="form-control">
            </div>
            <div class="mb-3">
                <label for="recieve_method" class="control-label">Способ получения: </label>
                <select name="recieve_method" class="form-select" aria-label="Default select example">
                    <option value="самовывоз">Самовывоз</option>
                    <option value="доставка">Доставка</option>
                </select>
            </div>
            {{-- <div class="mb-3">
                <label for="email" class="form-label">Подтвердите пароль</label>
                <input type="password" class="form-control">
            </div> --}}
            @csrf
            <input type="submit" class="order-btn mt-4" value="Подтвердите заказ">
        </form>
    </div>
@endsection
